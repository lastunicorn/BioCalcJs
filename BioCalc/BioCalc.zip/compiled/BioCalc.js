window.lu = window.lu || {};
lu.bioCalc = lu.bioCalc || {};
(function Version() {
  Object.defineProperty(lu.bioCalc, "version", {value:"1.5.0", writable:false, enumerable:true, configurable:false})
})();
window.lu = window.lu || {};
lu.bioCalc = lu.bioCalc || {};
lu.bioCalc.helpers = lu.bioCalc.helpers || {};
lu.bioCalc.helpers.DateFormatter = function() {
  function toStringTwoDigits(number) {
    if(typeof number !== "number") {
      return"" + number
    }
    return number < 10 ? "0" + number : "" + number
  }
  function formatDate(date) {
    if(!(date instanceof Date)) {
      return""
    }
    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    var day = date.getDate();
    var monthString = toStringTwoDigits(month);
    var dayString = toStringTwoDigits(day);
    return year + "-" + monthString + "-" + dayString
  }
  return{formatDate:formatDate}
}();
window.lu = window.lu || {};
lu.bioCalc = lu.bioCalc || {};
lu.bioCalc.helpers = lu.bioCalc.helpers || {};
(function($) {
  lu.bioCalc.helpers.ModalDialogsAutoCloseModule = function() {
    this.start = function() {
      $(document.body).on("click", ".ui-widget-overlay", onWidgetOverlayClick)
    };
    function onWidgetOverlayClick() {
      var $dialog = $(".ui-dialog");
      $.each($dialog, function() {
        var $dialogContent = $(this).children(".ui-dialog-content");
        var isModal = $dialogContent.dialog("option", "modal");
        if(isModal) {
          $dialogContent.dialog("close")
        }
      })
    }
  }
})(jQuery);
window.lu = window.lu || {};
lu.bioCalc = lu.bioCalc || {};
lu.bioCalc.configuration = lu.bioCalc.configuration || {};
(function() {
  lu.bioCalc.configuration.ConfigurationEqualityComparer = function() {
    var firstConfig = null;
    var secondConfig = null;
    this.areEqual = function(config1, config2) {
      if(config1 === undefined || config2 === undefined || config1 === null || config2 === null) {
        return false
      }
      firstConfig = config1;
      secondConfig = config2;
      return areEqualBirthdays() && areEqualSecondBirthdays() && areEqualBiorhythmArrays()
    };
    function areEqualBirthdays() {
      if(!firstConfig.birthday && !secondConfig.birthday) {
        return true
      }
      if(!firstConfig.birthday || !secondConfig.birthday) {
        return false
      }
      return firstConfig.birthday.getTime() === secondConfig.birthday.getTime()
    }
    function areEqualSecondBirthdays() {
      if(!firstConfig.secondBirthday && !secondConfig.secondBirthday) {
        return true
      }
      if(!firstConfig.secondBirthday || !secondConfig.secondBirthday) {
        return false
      }
      return firstConfig.secondBirthday.getTime() === secondConfig.secondBirthday.getTime()
    }
    function areEqualBiorhythmArrays() {
      if(!firstConfig.biorhythms && !secondConfig.biorhythms) {
        return true
      }
      if(!firstConfig.biorhythms || !secondConfig.biorhythms) {
        return false
      }
      if(!(firstConfig.biorhythms instanceof Array) || !(secondConfig.biorhythms instanceof Array)) {
        return false
      }
      var unchangedCount = 0;
      for(var i = 0;i < firstConfig.biorhythms.length;i++) {
        var secondBiorhythm = getBiorhythmByName(secondConfig.biorhythms, firstConfig.biorhythms[i].name);
        if(secondBiorhythm === null) {
          return false
        }
        var areEqual = areBiorhythmsEqual(firstConfig.biorhythms[i], secondBiorhythm);
        if(!areEqual) {
          return false
        }
        unchangedCount++
      }
      return unchangedCount === firstConfig.biorhythms.length
    }
    function getBiorhythmByName(biorhythms, name) {
      for(var j = 0;j < biorhythms.length;j++) {
        if(biorhythms[j].name === name) {
          return biorhythms[j]
        }
      }
      return null
    }
    function areBiorhythmsEqual(biorhythm1, biorhythm2) {
      return biorhythm1.color === biorhythm2.color
    }
  }
})();
window.lu = window.lu || {};
lu.bioCalc = lu.bioCalc || {};
lu.bioCalc.configuration = lu.bioCalc.configuration || {};
(function() {
  lu.bioCalc.configuration.JsonSerializer = function() {
    this.serialize = function(config) {
      return JSON.stringify(config)
    };
    this.deserialize = function(json) {
      return JSON.parse(json)
    }
  }
})();
window.lu = window.lu || {};
lu.bioCalc = lu.bioCalc || {};
lu.bioCalc.configuration = lu.bioCalc.configuration || {};
(function() {
  lu.bioCalc.configuration.UrlSerializer = function() {
    this.serialize = function(config) {
      var sb = [];
      sb.push("?birthday\x3d");
      sb.push(config.birthday);
      sb.push("\x26secondBirthday\x3d");
      sb.push(config.secondBirthday);
      return String.join(sb)
    };
    this.deserialize = function(json) {
      return{}
    }
  }
})();
window.lu = window.lu || {};
lu.bioCalc = lu.bioCalc || {};
lu.bioCalc.configuration = lu.bioCalc.configuration || {};
(function() {
  lu.bioCalc.configuration.CookieConfiguration = function() {
    var cookieName = "config";
    var config = null;
    Object.defineProperty(this, "config", {enumerable:true, configurable:false, get:function() {
      return config
    }});
    this.save = function(newConfig) {
      config = newConfig;
      $.cookie.json = true;
      if(config == null) {
        return
      }
      $.cookie(cookieName, config)
    };
    this.reset = function() {
      $.cookie.json = true;
      config = $.cookie(cookieName);
      ensureDefaultValues();
      return config
    };
    this.getDefaultConfig = function() {
      return createDefaultConfig()
    };
    function ensureDefaultValues() {
      if(!config) {
        config = {}
      }
      if($.type(config.birthday) === "string") {
        config.birthday = new Date(config.birthday)
      }
      if($.type(config.birthday) !== "date") {
        config.birthday = getDefaultBirthday()
      }
      if($.type(config.secondBirthday) === "string") {
        config.secondBirthday = new Date(config.secondBirthday)
      }
      if($.type(config.secondBirthday) !== "date") {
        config.secondBirthday = getDefaultBirthday()
      }
      if($.type(config.biorhythms) !== "array") {
        config.biorhythms = getDefaultBiorhythms()
      }
    }
    function createDefaultConfig() {
      return{birthday:getDefaultBirthday(), secondBirthday:getDefaultBirthday(), biorhythms:getDefaultBiorhythms()}
    }
    function getDefaultBirthday() {
      return new Date(1980, 5, 13)
    }
    function getDefaultBiorhythms() {
      return[{"name":"Physical Shape", "color":"#ff0000"}, {"name":"Emotional Shape", "color":"#32cd32"}, {"name":"Intellectual Shape", "color":"#1e90ff"}, {"name":"Intuitive Shape", "color":"#ffa500"}]
    }
  }
})();
window.lu = window.lu || {};
lu.bioCalc = lu.bioCalc || {};
lu.bioCalc.mainPage = lu.bioCalc.mainPage || {};
lu.bioCalc.mainPage.commands = lu.bioCalc.mainPage.commands || {};
lu.bioCalc.mainPage.commands.DialogCommand = function(dialog) {
  this.execute = function() {
    dialog.show()
  }
};
window.lu = window.lu || {};
lu.bioCalc = lu.bioCalc || {};
lu.bioCalc.mainPage = lu.bioCalc.mainPage || {};
lu.bioCalc.mainPage.commands = lu.bioCalc.mainPage.commands || {};
lu.bioCalc.mainPage.commands.SaveCommand = function(bioCalcPageData) {
  this.execute = function() {
    bioCalcPageData.saveIntoCookies()
  }
};
window.lu = window.lu || {};
lu.bioCalc = lu.bioCalc || {};
lu.bioCalc.mainPage = lu.bioCalc.mainPage || {};
lu.bioCalc.mainPage.commands = lu.bioCalc.mainPage.commands || {};
lu.bioCalc.mainPage.commands.LoadCommand = function(bioCalcPageData) {
  this.execute = function() {
    bioCalcPageData.loadFromCookies()
  }
};
window.lu = window.lu || {};
lu.bioCalc = lu.bioCalc || {};
lu.bioCalc.mainPage = lu.bioCalc.mainPage || {};
lu.bioCalc.mainPage.commands = lu.bioCalc.mainPage.commands || {};
lu.bioCalc.mainPage.commands.ClearCommand = function(bioCalcPageData) {
  this.execute = function() {
    bioCalcPageData.clear()
  }
};
window.lu = window.lu || {};
lu.bioCalc = lu.bioCalc || {};
lu.bioCalc.mainPage = lu.bioCalc.mainPage || {};
(function(Event, ConfigurationEqualityComparer, JsonSerializer, UrlSerializer) {
  lu.bioCalc.mainPage.BioCalcPageData = function(configuration) {
    var birthday = null;
    var birthdayChangedEvent = new Event;
    this.birthdayChanged = birthdayChangedEvent.client;
    Object.defineProperty(this, "birthday", {enumerable:true, configurable:false, get:getBirthday, set:setBirthday});
    function getBirthday() {
      return birthday
    }
    function setBirthday(value) {
      birthday = value;
      birthdayChangedEvent.raise(this, value)
    }
    var secondBirthday = null;
    var secondBirthdayChangedEvent = new Event;
    this.secondBirthdayChanged = secondBirthdayChangedEvent.client;
    Object.defineProperty(this, "secondBirthday", {enumerable:true, configurable:false, get:getSecondBirthday, set:setSecondBirthday});
    function getSecondBirthday() {
      return secondBirthday
    }
    function setSecondBirthday(value) {
      secondBirthday = value;
      secondBirthdayChangedEvent.raise(this, value)
    }
    var xDay = null;
    var xDayChangedEvent = new Event;
    this.xDayChanged = xDayChangedEvent.client;
    Object.defineProperty(this, "xDay", {enumerable:true, configurable:false, get:getXDay, set:setXDay});
    function getXDay() {
      return xDay
    }
    function setXDay(value) {
      xDay = value;
      xDayChangedEvent.raise(this, value)
    }
    var biorhythms = null;
    var biorhythmsChangedEvent = new Event;
    this.biorhythmsChanged = biorhythmsChangedEvent.client;
    Object.defineProperty(this, "biorhythms", {enumerable:true, configurable:false, get:getBiorhythms, set:setBiorhythms});
    function getBiorhythms() {
      return biorhythms
    }
    function setBiorhythms(value) {
      biorhythms = value;
      if(biorhythms) {
        biorhythms.setBirthdayOnAll(birthday);
        loadBiorhythmsConfigurationFromConfig(configuration.config.biorhythms)
      }
      biorhythmsChangedEvent.raise(this, value)
    }
    var savedEvent = new Event;
    this.saved = savedEvent.client;
    var loadedEvent = new Event;
    this.loaded = loadedEvent.client;
    this.saveIntoCookies = function() {
      var newConfig = toConfigObject();
      configuration.save(newConfig);
      savedEvent.raise()
    };
    this.loadFromCookies = function() {
      var config = configuration.config;
      loadFromConfig(config);
      loadedEvent.raise()
    };
    this.clear = function() {
      var config = configuration.getDefaultConfig();
      loadFromConfig(config);
      loadedEvent.raise()
    };
    this.toJson = function() {
      var config = toConfigObject();
      var serializer = new JsonSerializer;
      return serializer.serialize(config)
    };
    this.fromJson = function(json) {
      var serializer = new JsonSerializer;
      var config = serializer.deserialize(json);
      loadFromConfig(config);
      loadedEvent.raise()
    };
    this.toUrl = function() {
      var config = toConfigObject();
      var serializer = new UrlSerializer;
      return serializer.serialize(config)
    };
    this.fromUrl = function(url) {
      var serializer = new UrlSerializer;
      var config = serializer.deserialize(url);
      loadFromConfig(config);
      loadedEvent.raise()
    };
    function loadFromConfig(config) {
      setBirthday(config.birthday);
      setSecondBirthday(config.secondBirthday);
      loadBiorhythmsConfigurationFromConfig(config.biorhythms)
    }
    function loadBiorhythmsConfigurationFromConfig(biorhythmsConfig) {
      if(!biorhythms) {
        return
      }
      var biorhythmShapes = biorhythms.toArray();
      for(var i = 0;i < biorhythmShapes.length;i++) {
        var biorhythmShape = biorhythmShapes[i];
        var biorhythmConfig = getBiorhythmConfigByName(biorhythmsConfig, biorhythmShape.name);
        configureBiorhythmShape(biorhythmShape, biorhythmConfig)
      }
    }
    function configureBiorhythmShape(biorhythmShape, biorhythmConfig) {
      if(!biorhythmConfig) {
        biorhythmShape.isVisible = false;
        return
      }
      biorhythmShape.isVisible = true;
      biorhythmShape.color = biorhythmConfig.color
    }
    function getBiorhythmConfigByName(biorhythmsConfig, name) {
      if(!biorhythmsConfig) {
        return null
      }
      for(var i = 0;i < biorhythmsConfig.length;i++) {
        if(biorhythmsConfig[i].name == name) {
          return biorhythmsConfig[i]
        }
      }
      return null
    }
    this.isDataDefault = function() {
      var currentConfig = toConfigObject();
      var defaultConfig = configuration.getDefaultConfig();
      var comparer = new ConfigurationEqualityComparer;
      return comparer.areEqual(currentConfig, defaultConfig)
    };
    this.isDataChanged = function() {
      var currentConfig = toConfigObject();
      var comparer = new ConfigurationEqualityComparer;
      return!comparer.areEqual(currentConfig, configuration.config)
    };
    function toConfigObject() {
      var config = {};
      config.birthday = birthday;
      config.secondBirthday = secondBirthday;
      config.biorhythms = [];
      if(biorhythms && typeof biorhythms.toArray === "function") {
        var biorhythmShapes = biorhythms.toArray();
        for(var i = 0;i < biorhythmShapes.length;i++) {
          if(!biorhythmShapes[i].isVisible) {
            continue
          }
          config.biorhythms.push({name:biorhythmShapes[i].name, color:biorhythmShapes[i].color})
        }
      }
      return config
    }
    (function initialize() {
      var config = configuration.config;
      loadFromConfig(config)
    })()
  }
})(lu.Event, lu.bioCalc.configuration.ConfigurationEqualityComparer, lu.bioCalc.configuration.JsonSerializer, lu.bioCalc.configuration.UrlSerializer);
(function BioCalc($, BioCalcPageData, Configuration, OnePersonBiorhythms, ModalDialogsAutoCloseModule) {
  var configuration;
  var bioCalcPageData;
  (function initialize() {
    loadConfiguration();
    initializeBioCalcPageData();
    $(function() {
      initializeDialogsAutoCloseModule();
      createPageSections()
    })
  })();
  function loadConfiguration() {
    configuration = new Configuration;
    configuration.reset()
  }
  function initializeBioCalcPageData() {
    bioCalcPageData = new BioCalcPageData(configuration);
    var biorhythms = new OnePersonBiorhythms;
    bioCalcPageData.biorhythms = biorhythms
  }
  function initializeDialogsAutoCloseModule() {
    var modalDialogsAutoCloseModule = new ModalDialogsAutoCloseModule;
    modalDialogsAutoCloseModule.start()
  }
  function createPageSections() {
    var helpDialog = new lu.bioCalc.mainPage.pageSections.HelpDialog;
    helpDialog.view = new lu.bioCalc.mainPage.pageSections.HelpDialogView;
    var aboutDialog = new lu.bioCalc.mainPage.pageSections.AboutDialog;
    aboutDialog.view = new lu.bioCalc.mainPage.pageSections.AboutDialogView;
    var optionsDialog = new lu.bioCalc.mainPage.pageSections.OptionsDialog(bioCalcPageData);
    optionsDialog.view = new lu.bioCalc.mainPage.pageSections.OptionsDialogView;
    var mainToolbarCommands = {saveCommand:new lu.bioCalc.mainPage.commands.SaveCommand(bioCalcPageData), loadCommand:new lu.bioCalc.mainPage.commands.LoadCommand(bioCalcPageData), clearCommand:new lu.bioCalc.mainPage.commands.ClearCommand(bioCalcPageData), helpDialogCommand:new lu.bioCalc.mainPage.commands.DialogCommand(helpDialog), aboutDialogCommand:new lu.bioCalc.mainPage.commands.DialogCommand(aboutDialog), optionsDialogCommand:new lu.bioCalc.mainPage.commands.DialogCommand(optionsDialog)};
    var mainToolbar = new lu.bioCalc.mainPage.pageSections.MainToolbar(bioCalcPageData, mainToolbarCommands);
    mainToolbar.view = new lu.bioCalc.mainPage.pageSections.MainToolbarView;
    var chartsSection = new lu.bioCalc.mainPage.pageSections.ChartsSection(bioCalcPageData);
    chartsSection.view = new lu.bioCalc.mainPage.pageSections.ChartsSectionView;
    var birthdaySection = new lu.bioCalc.mainPage.pageSections.BirthdaySection(bioCalcPageData);
    birthdaySection.view = new lu.bioCalc.mainPage.pageSections.BirthdaySectionView;
    var xDaySection = new lu.bioCalc.mainPage.pageSections.XDaySection(bioCalcPageData);
    xDaySection.view = new lu.bioCalc.mainPage.pageSections.XDaySectionView
  }
})(jQuery, lu.bioCalc.mainPage.BioCalcPageData, lu.bioCalc.configuration.CookieConfiguration, lu.bioControls.biorhythmModel.OnePersonBiorhythms, lu.bioCalc.helpers.ModalDialogsAutoCloseModule);
window.lu = window.lu || {};
lu.bioCalc = lu.bioCalc || {};
lu.bioCalc.mainPage = lu.bioCalc.mainPage || {};
lu.bioCalc.mainPage.pageSections = lu.bioCalc.mainPage.pageSections || {};
(function($) {
  lu.bioCalc.mainPage.pageSections.AboutDialogView = function() {
    var $aboutDialog = null;
    var $aboutDialogTabSet = null;
    var $jQueryVersionLabel = null;
    var $jQueryUIVersionLabel = null;
    var $bioControlsVersionLabel = null;
    var $bioCalcVersionLabel = null;
    var presenter = null;
    Object.defineProperty(this, "presenter", {enumerable:true, configurable:false, get:getPresenter, set:setPresenter});
    function getPresenter() {
      return presenter
    }
    function setPresenter(value) {
      presenter = value
    }
    this.show = function() {
      $aboutDialog.dialog("open")
    };
    this.close = function() {
      $aboutDialog.dialog("close")
    };
    this.setJQueryVersionText = function(value) {
      $jQueryVersionLabel.html(value)
    };
    this.setJQueryUIVersionText = function(value) {
      $jQueryUIVersionLabel.html(value)
    };
    this.setBioControlsVersionText = function(value) {
      $bioControlsVersionLabel.html(value)
    };
    this.setBioCalcVersionText = function(value) {
      $bioCalcVersionLabel.html(value)
    };
    function onCloseButtonClicked(e) {
      if($.isFunction(presenter.onCloseButtonClicked)) {
        presenter.onCloseButtonClicked(e)
      }
    }
    (function initialize() {
      create$();
      initialize$()
    })();
    function create$() {
      $aboutDialog = $("#aboutDialog");
      $aboutDialogTabSet = $("#aboutDialog .tabs");
      $jQueryVersionLabel = $("#jQueryVersionLabel");
      $jQueryUIVersionLabel = $("#jQueryUIVersionLabel");
      $bioControlsVersionLabel = $("#bioControlsVersionLabel");
      $bioCalcVersionLabel = $(".bio-calc-version")
    }
    function initialize$() {
      $aboutDialog.dialog({modal:true, height:480, width:480, autoOpen:false, buttons:{Close:onCloseButtonClicked}, show:{effect:"puff", duration:300}, hide:{effect:"puff", duration:300}});
      $aboutDialogTabSet.tabs()
    }
  }
})(jQuery);
window.lu = window.lu || {};
lu.bioCalc = lu.bioCalc || {};
lu.bioCalc.mainPage = lu.bioCalc.mainPage || {};
lu.bioCalc.mainPage.pageSections = lu.bioCalc.mainPage.pageSections || {};
(function($) {
  lu.bioCalc.mainPage.pageSections.HelpDialogView = function() {
    var $helpDialog = null;
    var $helpDialogTabSet = null;
    var presenter = null;
    Object.defineProperty(this, "presenter", {enumerable:true, configurable:false, get:getPresenter, set:setPresenter});
    function getPresenter() {
      return presenter
    }
    function setPresenter(value) {
      presenter = value
    }
    this.show = function() {
      $helpDialog.dialog("open")
    };
    this.close = function() {
      $helpDialog.dialog("close")
    };
    function onCloseButtonClicked(e) {
      if($.isFunction(presenter.onCloseButtonClicked)) {
        presenter.onCloseButtonClicked(e)
      }
    }
    (function initialize() {
      create$();
      initialize$()
    })();
    function create$() {
      $helpDialog = $("#helpDialog");
      $helpDialogTabSet = $("#helpDialog .tabs")
    }
    function initialize$() {
      $helpDialog.dialog({modal:true, height:480, width:640, autoOpen:false, buttons:{Close:onCloseButtonClicked}, show:{effect:"puff", duration:300}, hide:{effect:"puff", duration:300}});
      $helpDialogTabSet.tabs()
    }
  }
})(jQuery);
window.lu = window.lu || {};
lu.bioCalc = lu.bioCalc || {};
lu.bioCalc.mainPage = lu.bioCalc.mainPage || {};
lu.bioCalc.mainPage.pageSections = lu.bioCalc.mainPage.pageSections || {};
(function($) {
  lu.bioCalc.mainPage.pageSections.OptionsDialogView = function() {
    var $optionsDialog = null;
    var $primaryBiorhythmsCheckbox = null;
    var $secondaryBiorhythmsCheckbox = null;
    var $extraBiorhythmsCheckbox = null;
    var $iChingBiorhythmsCheckbox = null;
    var presenter = null;
    Object.defineProperty(this, "presenter", {enumerable:true, configurable:false, get:getPresenter, set:setPresenter});
    function getPresenter() {
      return presenter
    }
    function setPresenter(value) {
      presenter = value
    }
    this.show = function() {
      $optionsDialog.dialog("open")
    };
    this.close = function() {
      $optionsDialog.dialog("close")
    };
    this.checkPrimaryBiorhythmsCheckbox = function(value) {
      $primaryBiorhythmsCheckbox.prop("checked", value)
    };
    this.checkSecondaryBiorhythmsCheckbox = function(value) {
      $secondaryBiorhythmsCheckbox.prop("checked", value)
    };
    this.checkExtraBiorhythmsCheckbox = function(value) {
      $extraBiorhythmsCheckbox.prop("checked", value)
    };
    this.checkIChingBiorhythmsCheckbox = function(value) {
      $iChingBiorhythmsCheckbox.prop("checked", value)
    };
    this.isCheckedPrimaryBiorhythmsCheckbox = function() {
      return $primaryBiorhythmsCheckbox.prop("checked")
    };
    this.isCheckedSecondaryBiorhythmsCheckbox = function() {
      return $secondaryBiorhythmsCheckbox.prop("checked")
    };
    this.isCheckedExtraBiorhythmsCheckbox = function() {
      return $extraBiorhythmsCheckbox.prop("checked")
    };
    this.isCheckedIChingBiorhythmsCheckbox = function() {
      return $iChingBiorhythmsCheckbox.prop("checked")
    };
    function onCloseButtonClicked(e) {
      if($.isFunction(presenter.onCloseButtonClicked)) {
        presenter.onCloseButtonClicked(e)
      }
    }
    function onOptionsDialogOpen() {
      if($.isFunction(presenter.onOptionsDialogOpen)) {
        presenter.onOptionsDialogOpen()
      }
    }
    function onOptionsDialogClose() {
      if($.isFunction(presenter.onOptionsDialogClose)) {
        presenter.onOptionsDialogClose()
      }
    }
    function onPrimaryCheckboxChange(e) {
      if($.isFunction(presenter.onPrimaryCheckboxChange)) {
        presenter.onPrimaryCheckboxChange(e)
      }
    }
    function onSecondaryCheckboxChange(e) {
      if($.isFunction(presenter.onSecondaryCheckboxChange)) {
        presenter.onSecondaryCheckboxChange(e)
      }
    }
    function onExtraCheckboxChange(e) {
      if($.isFunction(presenter.onExtraCheckboxChange)) {
        presenter.onExtraCheckboxChange(e)
      }
    }
    function onIChingCheckboxChange(e) {
      if($.isFunction(presenter.onIChingCheckboxChange)) {
        presenter.onIChingCheckboxChange(e)
      }
    }
    (function initialize() {
      create$();
      initialize$()
    })();
    function create$() {
      $optionsDialog = $("#optionsDialog");
      $primaryBiorhythmsCheckbox = $("#primaryBiorhythmsCheckbox");
      $secondaryBiorhythmsCheckbox = $("#secondaryBiorhythmsCheckbox");
      $extraBiorhythmsCheckbox = $("#extraBiorhythmsCheckbox");
      $iChingBiorhythmsCheckbox = $("#iChingBiorhythmsCheckbox")
    }
    function initialize$() {
      $optionsDialog.dialog({height:360, width:480, autoOpen:false, buttons:{Close:onCloseButtonClicked}, show:{effect:"puff", duration:300}, hide:{effect:"puff", duration:300}, open:onOptionsDialogOpen, close:onOptionsDialogClose});
      $primaryBiorhythmsCheckbox.change(onPrimaryCheckboxChange);
      $secondaryBiorhythmsCheckbox.change(onSecondaryCheckboxChange);
      $extraBiorhythmsCheckbox.change(onExtraCheckboxChange);
      $iChingBiorhythmsCheckbox.change(onIChingCheckboxChange)
    }
  }
})(jQuery);
window.lu = window.lu || {};
lu.bioCalc = lu.bioCalc || {};
lu.bioCalc.mainPage = lu.bioCalc.mainPage || {};
lu.bioCalc.mainPage.pageSections = lu.bioCalc.mainPage.pageSections || {};
(function($) {
  lu.bioCalc.mainPage.pageSections.BirthdaySectionView = function() {
    var $birthdayTextBox = null;
    var $secondBirthdayTextBox = null;
    var presenter = null;
    Object.defineProperty(this, "presenter", {enumerable:true, configurable:false, get:getPresenter, set:setPresenter});
    function getPresenter() {
      return presenter
    }
    function setPresenter(value) {
      presenter = value
    }
    this.setBirthdayText = function(value) {
      $birthdayTextBox.val(value)
    };
    this.setSecondBirthdayText = function(value) {
      $secondBirthdayTextBox.val(value)
    };
    this.getBirthday = function() {
      return $birthdayTextBox.datepicker("getDate")
    };
    this.getSecondBirthday = function() {
      return $secondBirthdayTextBox.datepicker("getDate")
    };
    function onBirthdayDatePickerSelect() {
      if($.isFunction(presenter.onBirthdayDatePickerSelect)) {
        presenter.onBirthdayDatePickerSelect()
      }
    }
    function onSecondBirthdayDatePickerSelect() {
      if($.isFunction(presenter.onSecondBirthdayDatePickerSelect)) {
        presenter.onSecondBirthdayDatePickerSelect()
      }
    }
    (function initialize() {
      create$();
      initialize$()
    })();
    function create$() {
      $birthdayTextBox = $("#birthdayTextBox");
      $secondBirthdayTextBox = $("#secondBirthdayTextBox");
      $saveBirthdayButton = $("#saveBirthdayButton");
      $resetBirthdayButton = $("#resetBirthdayButton");
      $birthdayButtons = $("#birthdayButtons")
    }
    function initialize$() {
      $birthdayTextBox.datepicker({changeMonth:true, changeYear:true, dateFormat:"yy-mm-dd", onSelect:onBirthdayDatePickerSelect, showButtonPanel:true});
      $secondBirthdayTextBox.datepicker({changeMonth:true, changeYear:true, dateFormat:"yy-mm-dd", onSelect:onSecondBirthdayDatePickerSelect, showButtonPanel:true})
    }
  }
})(jQuery);
window.lu = window.lu || {};
lu.bioCalc = lu.bioCalc || {};
lu.bioCalc.mainPage = lu.bioCalc.mainPage || {};
lu.bioCalc.mainPage.pageSections = lu.bioCalc.mainPage.pageSections || {};
(function($) {
  lu.bioCalc.mainPage.pageSections.MainToolbarView = function() {
    var $mainToolbar = null;
    var $helpButton = null;
    var $aboutButton = null;
    var $optionsButton = null;
    var $saveButton = null;
    var $loadButton = null;
    var $clearButton = null;
    var $saveMenuButton = null;
    var $saveMenu = null;
    var presenter = null;
    Object.defineProperty(this, "presenter", {enumerable:true, configurable:false, get:getPresenter, set:setPresenter});
    function getPresenter() {
      return presenter
    }
    function setPresenter(value) {
      presenter = value
    }
    this.enableSaveButton = function() {
      $saveButton.button("option", "disabled", false)
    };
    this.disableSaveButton = function() {
      $saveButton.button("option", "disabled", true)
    };
    this.enableLoadButton = function() {
      $loadButton.button("option", "disabled", false)
    };
    this.disableLoadButton = function() {
      $loadButton.button("option", "disabled", true)
    };
    this.enableClearButton = function() {
      $clearButton.button("option", "disabled", false)
    };
    this.disableClearButton = function() {
      $clearButton.button("option", "disabled", true)
    };
    function onHelpButtonClick(e) {
      if($.isFunction(presenter.onHelpButtonClick)) {
        presenter.onHelpButtonClick(e)
      }
    }
    function onAboutButtonClick(e) {
      if($.isFunction(presenter.onAboutButtonClick)) {
        presenter.onAboutButtonClick(e)
      }
    }
    function onOptionsButtonClick(e) {
      if($.isFunction(presenter.onOptionsButtonClick)) {
        presenter.onOptionsButtonClick(e)
      }
    }
    function onSaveButtonClick(e) {
      if($.isFunction(presenter.onSaveButtonClick)) {
        presenter.onSaveButtonClick(e)
      }
    }
    function onLoadButtonClick(e) {
      if($.isFunction(presenter.onLoadButtonClick)) {
        presenter.onLoadButtonClick(e)
      }
    }
    function onClearButtonClick(e) {
      if($.isFunction(presenter.onClearButtonClick)) {
        presenter.onClearButtonClick(e)
      }
    }
    function onSaveMenuButtonClick(e) {
      $saveMenu.show().position({my:"right top", at:"right bottom", of:$saveMenuButton});
      $(document).one("click", function() {
        $saveMenu.hide()
      })
    }
    (function initialize() {
      createControls();
      initializeControls()
    })();
    function createControls() {
      $mainToolbar = $("#mainToolbar");
      $helpButton = $("#helpButton");
      $aboutButton = $("#aboutButton");
      $optionsButton = $("#optionsButton");
      $saveButton = $("#saveButton");
      $loadButton = $("#loadButton");
      $clearButton = $("#clearButton");
      $saveMenuButton = $("#saveMenuButton");
      $saveMenu = $("#saveMenu")
    }
    function initializeControls() {
      $mainToolbar.buttonset();
      $helpButton.button({icons:{primary:"ui-icon-help"}, text:true});
      $helpButton.click(onHelpButtonClick);
      $aboutButton.button({icons:{primary:"ui-icon-star"}, text:true});
      $aboutButton.click(onAboutButtonClick);
      $optionsButton.button({icons:{primary:"ui-icon-gear"}});
      $optionsButton.click(onOptionsButtonClick);
      $saveButton.button({icons:{primary:"ui-icon-disk"}});
      $saveButton.click(onSaveButtonClick);
      $loadButton.button({icons:{primary:"ui-icon-disk"}});
      $loadButton.click(onLoadButtonClick);
      $clearButton.button({icons:{primary:"ui-icon-document"}});
      $clearButton.click(onClearButtonClick);
      $saveMenuButton.button({text:false, icons:{primary:"ui-icon-triangle-1-s"}});
      $saveMenuButton.hide();
      $saveMenuButton.click(onSaveMenuButtonClick);
      $saveMenu.menu().hide()
    }
  }
})(jQuery);
window.lu = window.lu || {};
lu.bioCalc = lu.bioCalc || {};
lu.bioCalc.mainPage = lu.bioCalc.mainPage || {};
lu.bioCalc.mainPage.pageSections = lu.bioCalc.mainPage.pageSections || {};
(function($) {
  lu.bioCalc.mainPage.pageSections.XDaySectionView = function() {
    var $xDayValueLabel = null;
    var $xDayInfoContainer = null;
    this.setBiorhythms = function(value) {
      $xDayInfoContainer.xDayInfoView("option", "biorhythms", value)
    };
    this.setXDay = function(value) {
      $xDayInfoContainer.xDayInfoView("updateXDay", value)
    };
    this.setSecondBirthday = function(value) {
      $xDayInfoContainer.xDayInfoView("updateSecondBirthday", value)
    };
    this.setTitle = function(value) {
      $xDayValueLabel.html(value)
    };
    (function initialize() {
      create$();
      initialize$()
    })();
    function create$() {
      $xDayValueLabel = $("#xDayValueLabel");
      $xDayInfoContainer = $("#xDayInfoContainer")
    }
    function initialize$() {
      $xDayInfoContainer.xDayInfoView()
    }
  }
})(jQuery);
window.lu = window.lu || {};
lu.bioCalc = lu.bioCalc || {};
lu.bioCalc.mainPage = lu.bioCalc.mainPage || {};
lu.bioCalc.mainPage.pageSections = lu.bioCalc.mainPage.pageSections || {};
(function($) {
  lu.bioCalc.mainPage.pageSections.ChartsSectionView = function() {
    var $biorhythmViewContainer = null;
    Object.defineProperty(this, "$biorhythmViewContainer", {enumerable:true, configurable:false, get:function() {
      return $biorhythmViewContainer
    }});
    var $firstDayTextBox = null;
    Object.defineProperty(this, "$firstDayTextBox", {enumerable:true, configurable:false, get:function() {
      return $firstDayTextBox
    }});
    var $firstDayLabel = null;
    Object.defineProperty(this, "$firstDayLabel", {enumerable:true, configurable:false, get:function() {
      return $firstDayLabel
    }});
    var $lastDayTextBox = null;
    Object.defineProperty(this, "$lastDayTextBox", {enumerable:true, configurable:false, get:function() {
      return $lastDayTextBox
    }});
    var $lastDayLabel = null;
    Object.defineProperty(this, "$lastDayLabel", {enumerable:true, configurable:false, get:function() {
      return $lastDayLabel
    }});
    var $bioLegend = null;
    var presenter = null;
    Object.defineProperty(this, "presenter", {enumerable:true, configurable:false, get:getPresenter, set:setPresenter});
    function getPresenter() {
      return presenter
    }
    function setPresenter(value) {
      presenter = value
    }
    this.getBiorhythmsViewBirthday = function() {
      return $biorhythmViewContainer.biorhythmView("getXDay")
    };
    this.setFirstDayTextBoxText = function(text) {
      $firstDayTextBox.val(text)
    };
    this.setFirstDayLabelText = function(text) {
      $firstDayLabel.text(text)
    };
    this.setLastDayTextBoxText = function(text) {
      $lastDayTextBox.val(text)
    };
    this.setLastDayLabelText = function(text) {
      $lastDayLabel.text(text)
    };
    this.setBiorhythmViewFirstDay = function(date) {
      $biorhythmViewContainer.biorhythmView("option", "firstDay", date)
    };
    this.getBiorhythmViewFirstDay = function() {
      return $biorhythmViewContainer.biorhythmView("option", "firstDay")
    };
    this.getBiorhythmViewLastDay = function() {
      return $biorhythmViewContainer.biorhythmView("getLastDay")
    };
    this.setBioLegendBiorhythms = function(biorhythms) {
      $bioLegend.biorhythmLegend("option", "biorhythms", biorhythms)
    };
    this.setBiorhythmViewBiorhythms = function(biorhythms) {
      $biorhythmViewContainer.biorhythmView("option", "biorhythms", biorhythms)
    };
    this.getFirstDayTextBoxDate = function() {
      return $firstDayTextBox.datepicker("getDate")
    };
    this.getLastDayTextBoxDate = function() {
      return $lastDayTextBox.datepicker("getDate")
    };
    function onFirstDayLabelClick() {
      presenter.onFirstDayLabelClick.apply(this, arguments)
    }
    function onBeforeFirstDayDatePickerShow() {
      presenter.onBeforeFirstDayDatePickerShow.apply(this, arguments)
    }
    function onFirstDayDatePickerSelect() {
      presenter.onFirstDayDatePickerSelect.apply(this, arguments)
    }
    function onLastDayLabelClick() {
      presenter.onLastDayLabelClick.apply(this, arguments)
    }
    function onBeforeLastDayDatePickerShow() {
      presenter.onBeforeLastDayDatePickerShow.apply(this, arguments)
    }
    function onLastDayDatePickerSelect() {
      presenter.onLastDayDatePickerSelect.apply(this, arguments)
    }
    function onBiorhythmViewFirstDayChanged() {
      presenter.onBiorhythmViewFirstDayChanged.apply(this, arguments)
    }
    function onBiorhythmViewXDayIndexChanged() {
      presenter.onBiorhythmViewXDayIndexChanged.apply(this, arguments)
    }
    (function initialize() {
      create$();
      initialize$()
    })();
    function create$() {
      $biorhythmViewContainer = $("#biorhythmViewContainer");
      $firstDayLabel = $(".first-day-label");
      $firstDayTextBox = $(".first-day-textbox");
      $lastDayLabel = $(".last-day-label");
      $lastDayTextBox = $(".last-day-textbox");
      $bioLegend = $("#bioLegend")
    }
    function initialize$() {
      $firstDayLabel.click(onFirstDayLabelClick);
      $firstDayTextBox.datepicker({changeMonth:true, changeYear:true, dateFormat:"yy-mm-dd", showButtonPanel:true, showAnim:"", beforeShow:onBeforeFirstDayDatePickerShow, onSelect:onFirstDayDatePickerSelect});
      $lastDayLabel.click(onLastDayLabelClick);
      $lastDayTextBox.datepicker({changeMonth:true, changeYear:true, dateFormat:"yy-mm-dd", showButtonPanel:true, showAnim:"", beforeShow:onBeforeLastDayDatePickerShow, onSelect:onLastDayDatePickerSelect});
      $biorhythmViewContainer.biorhythmView({width:900, height:200, firstDayChanged:onBiorhythmViewFirstDayChanged, xDayIndexChanged:onBiorhythmViewXDayIndexChanged});
      $bioLegend.biorhythmLegend()
    }
  }
})(jQuery);
window.lu = window.lu || {};
lu.bioCalc = lu.bioCalc || {};
lu.bioCalc.mainPage = lu.bioCalc.mainPage || {};
lu.bioCalc.mainPage.pageSections = lu.bioCalc.mainPage.pageSections || {};
(function($, bioControlsVersion, bioCalcVersion) {
  lu.bioCalc.mainPage.pageSections.AboutDialog = function() {
    var presenter;
    var view = null;
    Object.defineProperty(this, "view", {enumerable:true, configurable:false, get:getView, set:setView});
    function getView() {
      return view
    }
    function setView(value) {
      if(view) {
        view.presenter = null
      }
      view = value;
      if(view) {
        view.presenter = presenter;
        initializeView()
      }
    }
    this.show = function() {
      view.show()
    };
    function initializeView() {
      view.setJQueryVersionText($.fn.jquery);
      view.setJQueryUIVersionText($.ui.version);
      view.setBioControlsVersionText(bioControlsVersion);
      view.setBioCalcVersionText("ver " + bioCalcVersion)
    }
    function onAboutDialogCloseClicked() {
      view.close()
    }
    (function initialize() {
      presenter = {onCloseButtonClicked:onAboutDialogCloseClicked}
    })()
  }
})(jQuery, lu.bioControls.version, lu.bioCalc.version);
window.lu = window.lu || {};
lu.bioCalc = lu.bioCalc || {};
lu.bioCalc.mainPage = lu.bioCalc.mainPage || {};
lu.bioCalc.mainPage.pageSections = lu.bioCalc.mainPage.pageSections || {};
(function() {
  lu.bioCalc.mainPage.pageSections.HelpDialog = function() {
    var presenter;
    var view = null;
    Object.defineProperty(this, "view", {enumerable:true, configurable:false, get:getView, set:setView});
    function getView() {
      return view
    }
    function setView(value) {
      if(view) {
        view.presenter = null
      }
      view = value;
      if(view) {
        view.presenter = presenter
      }
    }
    this.show = function() {
      view.show()
    };
    function onHelpDialogCloseClicked() {
      view.close()
    }
    (function initialize() {
      presenter = {onCloseButtonClicked:onHelpDialogCloseClicked}
    })()
  }
})();
window.lu = window.lu || {};
lu.bioCalc = lu.bioCalc || {};
lu.bioCalc.mainPage = lu.bioCalc.mainPage || {};
lu.bioCalc.mainPage.dialogs = lu.bioCalc.mainPage.dialogs || {};
(function() {
  lu.bioCalc.mainPage.pageSections.OptionsDialog = function(bioCalcPageData) {
    var presenter;
    var biorhythmShapes = null;
    var view = null;
    Object.defineProperty(this, "view", {enumerable:true, configurable:false, get:getView, set:setView});
    function getView() {
      return view
    }
    function setView(value) {
      if(view) {
        view.presenter = null
      }
      view = value;
      if(view) {
        view.presenter = presenter
      }
    }
    this.show = function() {
      view.show()
    };
    function start() {
      bioCalcPageData.biorhythmsChanged.subscribe(onExternalBiorhythmsChanged);
      biorhythmShapes = bioCalcPageData.biorhythms;
      var isAnyPrimaryVisible = biorhythmShapes.primaryBiorhythmShapes.isAnyVisible();
      view.checkPrimaryBiorhythmsCheckbox(isAnyPrimaryVisible);
      var isAnySecondaryVisible = biorhythmShapes.secondaryBiorhythmShapes.isAnyVisible();
      view.checkSecondaryBiorhythmsCheckbox(isAnySecondaryVisible);
      var isAnyExtraVisible = biorhythmShapes.extraBiorhythmShapes.isAnyVisible();
      view.checkExtraBiorhythmsCheckbox(isAnyExtraVisible);
      var isAnyIChingVisible = biorhythmShapes.iChingBiorhythmShapes.isAnyVisible();
      view.checkIChingBiorhythmsCheckbox(isAnyIChingVisible)
    }
    function stop() {
      bioCalcPageData.biorhythmsChanged.unsubscribe(onExternalBiorhythmsChanged)
    }
    function onOptionsDialogCloseClicked() {
      view.close()
    }
    function onOptionsDialogOpen() {
      start()
    }
    function onOptionsDialogClose() {
      stop()
    }
    function onPrimaryCheckboxChange() {
      var isChecked = view.isCheckedPrimaryBiorhythmsCheckbox();
      biorhythmShapes.primaryBiorhythmShapes.showAll(isChecked)
    }
    function onSecondaryCheckboxChange() {
      var isChecked = view.isCheckedSecondaryBiorhythmsCheckbox();
      biorhythmShapes.secondaryBiorhythmShapes.showAll(isChecked)
    }
    function onExtraCheckboxChange() {
      var isChecked = view.isCheckedExtraBiorhythmsCheckbox();
      biorhythmShapes.extraBiorhythmShapes.showAll(isChecked)
    }
    function onIChingCheckboxChange() {
      var isChecked = view.isCheckedIChingBiorhythmsCheckbox();
      biorhythmShapes.iChingBiorhythmShapes.showAll(isChecked)
    }
    function onExternalBiorhythmsChanged(arg) {
      biorhythmShapes = arg
    }
    (function initialize() {
      presenter = {onCloseButtonClicked:onOptionsDialogCloseClicked, onOptionsDialogOpen:onOptionsDialogOpen, onOptionsDialogClose:onOptionsDialogClose, onPrimaryCheckboxChange:onPrimaryCheckboxChange, onSecondaryCheckboxChange:onSecondaryCheckboxChange, onExtraCheckboxChange:onExtraCheckboxChange, onIChingCheckboxChange:onIChingCheckboxChange}
    })()
  }
})();
window.lu = window.lu || {};
lu.bioCalc = lu.bioCalc || {};
lu.bioCalc.mainPage = lu.bioCalc.mainPage || {};
lu.bioCalc.mainPage.pageSections = lu.bioCalc.mainPage.pageSections || {};
(function(dateFormatter) {
  lu.bioCalc.mainPage.pageSections.BirthdaySection = function(bioCalcPageData) {
    var presenter;
    var suppressBirthdayChanged = false;
    var suppressSecondBirthdayChanged = false;
    var view = null;
    Object.defineProperty(this, "view", {enumerable:true, configurable:false, get:getView, set:setView});
    function getView() {
      return view
    }
    function setView(value) {
      if(view) {
        view.presenter = null;
        stop()
      }
      view = value;
      if(view) {
        view.presenter = presenter;
        start()
      }
    }
    function refreshBirthdayTextBox() {
      var dateAsString = dateFormatter.formatDate(bioCalcPageData.birthday);
      view.setBirthdayText(dateAsString)
    }
    function refreshSecondBirthdayTextBox() {
      var dateAsString = dateFormatter.formatDate(bioCalcPageData.secondBirthday);
      view.setSecondBirthdayText(dateAsString)
    }
    function publishBirthday() {
      suppressBirthdayChanged = true;
      try {
        bioCalcPageData.birthday = view.getBirthday()
      }finally {
        suppressBirthdayChanged = false
      }
    }
    function publishSecondBirthday() {
      suppressSecondBirthdayChanged = true;
      try {
        bioCalcPageData.secondBirthday = view.getSecondBirthday()
      }finally {
        suppressSecondBirthdayChanged = false
      }
    }
    function start() {
      refreshBirthdayTextBox();
      refreshSecondBirthdayTextBox();
      bioCalcPageData.birthdayChanged.subscribe(onExternalBirthdayChanged);
      bioCalcPageData.secondBirthdayChanged.subscribe(onExternalSecondBirthdayChanged)
    }
    function stop() {
      bioCalcPageData.birthdayChanged.unsubscribe(onExternalBirthdayChanged);
      bioCalcPageData.secondBirthdayChanged.unsubscribe(onExternalSecondBirthdayChanged)
    }
    function onBirthdayDatePickerSelect() {
      publishBirthday()
    }
    function onSecondBirthdayDatePickerSelect() {
      publishSecondBirthday()
    }
    function onExternalBirthdayChanged() {
      if(suppressBirthdayChanged) {
        return
      }
      refreshBirthdayTextBox()
    }
    function onExternalSecondBirthdayChanged() {
      if(suppressSecondBirthdayChanged) {
        return
      }
      refreshSecondBirthdayTextBox()
    }
    (function initialize() {
      presenter = {onBirthdayDatePickerSelect:onBirthdayDatePickerSelect, onSecondBirthdayDatePickerSelect:onSecondBirthdayDatePickerSelect}
    })()
  }
})(lu.bioCalc.helpers.DateFormatter);
window.lu = window.lu || {};
lu.bioCalc = lu.bioCalc || {};
lu.bioCalc.mainPage = lu.bioCalc.mainPage || {};
lu.bioCalc.mainPage.pageSections = lu.bioCalc.mainPage.pageSections || {};
(function() {
  lu.bioCalc.mainPage.pageSections.MainToolbar = function(bioCalcPageData, commands) {
    var presenter;
    var view = null;
    Object.defineProperty(this, "view", {enumerable:true, configurable:false, get:getView, set:setView});
    function getView() {
      return view
    }
    function setView(value) {
      if(view) {
        view.presenter = null;
        stop()
      }
      view = value;
      if(view) {
        view.presenter = presenter;
        start()
      }
    }
    function updateAllButtonsVisibility() {
      updateSaveButtonVisibility();
      updateLoadButtonVisibility();
      updateClearButtonVisibility()
    }
    function updateSaveButtonVisibility() {
      var isDataChanged = bioCalcPageData.isDataChanged();
      if(isDataChanged) {
        view.enableSaveButton()
      }else {
        view.disableSaveButton()
      }
    }
    function updateLoadButtonVisibility() {
      var isDataChanged = bioCalcPageData.isDataChanged();
      if(isDataChanged) {
        view.enableLoadButton()
      }else {
        view.disableLoadButton()
      }
    }
    function updateClearButtonVisibility() {
      var isDataDefault = bioCalcPageData.isDataDefault();
      if(isDataDefault) {
        view.disableClearButton()
      }else {
        view.enableClearButton()
      }
    }
    function start() {
      bioCalcPageData.saved.subscribe(onPageDataSaved);
      bioCalcPageData.birthdayChanged.subscribe(onBirthdayChanged);
      bioCalcPageData.secondBirthdayChanged.subscribe(onSecondBirthdayChanged);
      subscribeToBiorhythmsEvents();
      updateAllButtonsVisibility()
    }
    function stop() {
      bioCalcPageData.saved.unsubscribe(onPageDataSaved);
      bioCalcPageData.birthdayChanged.unsubscribe(onBirthdayChanged);
      bioCalcPageData.secondBirthdayChanged.unsubscribe(onSecondBirthdayChanged);
      unsubscribeFromBiorhythmsEvents()
    }
    function subscribeToBiorhythmsEvents() {
      if(typeof bioCalcPageData.biorhythms.itemAdded === "object" && typeof bioCalcPageData.biorhythms.itemAdded.subscribe === "function") {
        bioCalcPageData.biorhythms.itemAdded.subscribe(onBiorhythmAdded)
      }
      if(typeof bioCalcPageData.biorhythms.itemRemoved === "object" && typeof bioCalcPageData.biorhythms.itemRemoved.subscribe === "function") {
        bioCalcPageData.biorhythms.itemRemoved.subscribe(onBiorhythmRemoved)
      }
      if(typeof bioCalcPageData.biorhythms !== "object") {
        return
      }
      var biorhythmShapes = bioCalcPageData.biorhythms.toArray();
      for(var i = 0;i < biorhythmShapes.length;i++) {
        subscribeToBiorhythmEvents(biorhythmShapes[i])
      }
    }
    function subscribeToBiorhythmEvents(biorhythmShape) {
      biorhythmShape.isVisibleChanged.subscribe(onBiorhythmVisibilityChanged);
      biorhythmShape.colorChanged.subscribe(onBiorhythmColorChanged)
    }
    function unsubscribeFromBiorhythmsEvents() {
      if(typeof bioCalcPageData.biorhythms.itemAdded === "object" && typeof bioCalcPageData.biorhythms.itemAdded.unsubscribe === "function") {
        bioCalcPageData.biorhythms.itemAdded.unsubscribe(onBiorhythmAdded)
      }
      if(typeof bioCalcPageData.biorhythms.itemRemoved === "object" && typeof bioCalcPageData.biorhythms.itemRemoved.unsubscribe === "function") {
        bioCalcPageData.biorhythms.itemRemoved.unsubscribe(onBiorhythmRemoved)
      }
      if(typeof bioCalcPageData.biorhythms !== "object") {
        return
      }
      var biorhythmShapes = bioCalcPageData.biorhythms.toArray();
      for(var i = 0;i < biorhythmShapes.length;i++) {
        unsubscribeFromBiorhythmEvents(biorhythmShapes[i])
      }
    }
    function unsubscribeFromBiorhythmEvents(biorhythmShape) {
      biorhythmShape.isVisibleChanged.unsubscribe(onBiorhythmVisibilityChanged);
      biorhythmShape.colorChanged.unsubscribe(onBiorhythmColorChanged)
    }
    function onHelpButtonClick() {
      commands.helpDialogCommand.execute()
    }
    function onAboutButtonClick() {
      commands.aboutDialogCommand.execute()
    }
    function onOptionsButtonClick() {
      commands.optionsDialogCommand.execute()
    }
    function onSaveButtonClick() {
      commands.saveCommand.execute()
    }
    function onLoadButtonClick() {
      commands.loadCommand.execute()
    }
    function onClearButtonClick() {
      commands.clearCommand.execute()
    }
    function onPageDataSaved() {
      updateAllButtonsVisibility()
    }
    function onBirthdayChanged() {
      updateAllButtonsVisibility()
    }
    function onSecondBirthdayChanged() {
      updateAllButtonsVisibility()
    }
    function onBiorhythmAdded(arg) {
      subscribeToBiorhythmEvents(arg);
      updateAllButtonsVisibility()
    }
    function onBiorhythmRemoved(arg) {
      unsubscribeFromBiorhythmEvents(arg);
      updateAllButtonsVisibility()
    }
    function onBiorhythmVisibilityChanged() {
      updateAllButtonsVisibility()
    }
    function onBiorhythmColorChanged() {
      updateAllButtonsVisibility()
    }
    (function initialize() {
      presenter = {onHelpButtonClick:onHelpButtonClick, onAboutButtonClick:onAboutButtonClick, onOptionsButtonClick:onOptionsButtonClick, onSaveButtonClick:onSaveButtonClick, onLoadButtonClick:onLoadButtonClick, onClearButtonClick:onClearButtonClick}
    })()
  }
})();
window.lu = window.lu || {};
lu.bioCalc = lu.bioCalc || {};
lu.bioCalc.mainPage = lu.bioCalc.mainPage || {};
lu.bioCalc.mainPage.pageSections = lu.bioCalc.mainPage.pageSections || {};
(function(dateFormatter) {
  lu.bioCalc.mainPage.pageSections.XDaySection = function(bioCalcPageData) {
    var view = null;
    Object.defineProperty(this, "view", {enumerable:true, configurable:false, get:getView, set:setView});
    function getView() {
      return view
    }
    function setView(value) {
      if(view) {
        stop()
      }
      view = value;
      if(view) {
        start()
      }
    }
    function start() {
      bioCalcPageData.xDayChanged.subscribe(onExternalXDayChanged);
      bioCalcPageData.biorhythmsChanged.subscribe(onExternalBiorhythmsChanged);
      bioCalcPageData.secondBirthdayChanged.subscribe(onSecondBirthdayChanged);
      refreshBiorhythms();
      refreshXDay();
      refreshSecondBirthday()
    }
    function stop() {
      bioCalcPageData.xDayChanged.unsubscribe(onExternalXDayChanged);
      bioCalcPageData.biorhythmsChanged.unsubscribe(onExternalBiorhythmsChanged);
      bioCalcPageData.secondBirthdayChanged.unsubscribe(onSecondBirthdayChanged)
    }
    function refreshXDay() {
      var xDay = bioCalcPageData.xDay;
      var title = dateFormatter.formatDate(xDay);
      view.setTitle(title);
      view.setXDay(xDay)
    }
    function refreshSecondBirthday() {
      var secondBirthday = bioCalcPageData.secondBirthday;
      view.setSecondBirthday(secondBirthday)
    }
    function refreshBiorhythms() {
      view.setBiorhythms(bioCalcPageData.biorhythms)
    }
    function onExternalXDayChanged(arg) {
      refreshXDay()
    }
    function onExternalBiorhythmsChanged(arg) {
      refreshBiorhythms()
    }
    function onSecondBirthdayChanged(arg) {
      refreshSecondBirthday()
    }
  }
})(lu.bioCalc.helpers.DateFormatter);
window.lu = window.lu || {};
lu.bioCalc = lu.bioCalc || {};
lu.bioCalc.mainPage = lu.bioCalc.mainPage || {};
lu.bioCalc.mainPage.pageSections = lu.bioCalc.mainPage.pageSections || {};
(function(dateFormatter, dateUtil) {
  lu.bioCalc.mainPage.pageSections.ChartsSection = function(bioCalcPageData) {
    var presenter;
    var view = null;
    Object.defineProperty(this, "view", {enumerable:true, configurable:false, get:getView, set:setView});
    function getView() {
      return view
    }
    function setView(value) {
      if(view) {
        view.presenter = null;
        stop()
      }
      view = value;
      if(view) {
        view.presenter = presenter;
        start()
      }
    }
    function publishCurrentXDay() {
      bioCalcPageData.xDay = view.getBiorhythmsViewBirthday()
    }
    function displayFirstDayLabel() {
      var date = view.getBiorhythmViewFirstDay();
      var dateAsText = dateFormatter.formatDate(date);
      view.setFirstDayTextBoxText(dateAsText);
      view.setFirstDayLabelText(dateAsText)
    }
    function displayLastDayLabel() {
      var date = view.getBiorhythmViewLastDay();
      var dateAsText = dateFormatter.formatDate(date);
      view.setLastDayTextBoxText(dateAsText);
      view.setLastDayLabelText(dateAsText)
    }
    function displayBiorhythms() {
      var biorhythms = bioCalcPageData.biorhythms;
      view.setBiorhythmViewBiorhythms(biorhythms);
      view.setBioLegendBiorhythms(biorhythms)
    }
    function displayBirthday() {
      view.$biorhythmViewContainer.biorhythmView("suspendPaint");
      try {
        var newBirthday = bioCalcPageData.birthday;
        bioCalcPageData.biorhythms.setBirthdayOnAll(newBirthday)
      }finally {
        view.$biorhythmViewContainer.biorhythmView("resumePaint")
      }
    }
    function start() {
      bioCalcPageData.birthdayChanged.subscribe(onExternalBirthdayChanged);
      bioCalcPageData.biorhythmsChanged.subscribe(onExternalBiorhythmsChanged);
      view.$biorhythmViewContainer.biorhythmView("suspendPaint");
      try {
        var firstDay = dateUtil.addDays(Date.now(), -7);
        view.setBiorhythmViewFirstDay(firstDay);
        displayFirstDayLabel();
        displayBiorhythms();
        displayBirthday();
        publishCurrentXDay()
      }finally {
        view.$biorhythmViewContainer.biorhythmView("resumePaint")
      }
    }
    function stop() {
      bioCalcPageData.birthdayChanged.unsubscribe(onExternalBirthdayChanged);
      bioCalcPageData.biorhythmsChanged.unsubscribe(onExternalBiorhythmsChanged)
    }
    function onBiorhythmViewFirstDayChanged() {
      displayFirstDayLabel();
      displayLastDayLabel();
      publishCurrentXDay()
    }
    function onFirstDayLabelClick() {
      setTimeout(function() {
        view.$firstDayTextBox.datepicker("show")
      }, 0)
    }
    function onFirstDayDatePickerSelect() {
      var firstDay = view.getFirstDayTextBoxDate();
      view.setBiorhythmViewFirstDay(firstDay)
    }
    function onBeforeFirstDayDatePickerShow(input, inst) {
      var calendar = inst.dpDiv;
      setTimeout(function() {
        calendar.position({my:"left top", at:"left bottom", collision:"none", of:view.$firstDayLabel})
      }, 0)
    }
    function onLastDayLabelClick() {
      setTimeout(function() {
        view.$lastDayTextBox.datepicker("show")
      }, 0)
    }
    function onLastDayDatePickerSelect() {
      var lastDay = view.getLastDayTextBoxDate();
      var displayedDayCount = view.$biorhythmViewContainer.biorhythmView("option", "totalDays") - 1;
      var firstDay = dateUtil.addDays(lastDay, -displayedDayCount);
      view.setBiorhythmViewFirstDay(firstDay)
    }
    function onBeforeLastDayDatePickerShow(input, inst) {
      var calendar = inst.dpDiv;
      setTimeout(function() {
        calendar.position({my:"right top", at:"right bottom", collision:"none", of:view.$lastDayLabel})
      }, 0)
    }
    function onBiorhythmViewXDayIndexChanged(sender, arg) {
      publishCurrentXDay()
    }
    function onExternalBirthdayChanged(arg) {
      displayBirthday();
      publishCurrentXDay()
    }
    function onExternalBiorhythmsChanged(arg) {
      displayBiorhythms()
    }
    (function initialize() {
      presenter = {onFirstDayLabelClick:onFirstDayLabelClick, onBeforeFirstDayDatePickerShow:onBeforeFirstDayDatePickerShow, onFirstDayDatePickerSelect:onFirstDayDatePickerSelect, onLastDayLabelClick:onLastDayLabelClick, onBeforeLastDayDatePickerShow:onBeforeLastDayDatePickerShow, onLastDayDatePickerSelect:onLastDayDatePickerSelect, onBiorhythmViewFirstDayChanged:onBiorhythmViewFirstDayChanged, onBiorhythmViewXDayIndexChanged:onBiorhythmViewXDayIndexChanged}
    })()
  }
})(lu.bioCalc.helpers.DateFormatter, lu.DateUtil);
