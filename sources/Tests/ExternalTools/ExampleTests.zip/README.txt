This directory contains sample QUnit and Jasmine test files. 
You can run these tests using Chutzpah by running one of of the following commands:

Running on JS file:
  chutzpah.console.exe qunitTests.js
  chutzpah.console.exe jasmineTests.js

Running HTML file:
  chutzpah.console.exe qunitTests.html
  chutzpah.console.exe jasmineTests.html